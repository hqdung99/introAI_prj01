# Project 01 of CSC14003: Search Algorithm

## Team info
>1712060 – Trần Vinh Hưng

>1712122 – Nguyễn Tiến Phát 

>1712366 – Huỳnh Quốc Dũng 

## How to use

Please use file `example.ipynb` to check animated example for all levels

### use command line:
There are three arguments you need to focus on:
1. search_name: type of search that you want to use
2. input_file: your input file
3. allpoint_type: this argument is necessary when you choose search_name = 'AllPointSearch'

**_List of valid values for the arguments above:_**

- **search_name**: BFS, DFS, Greedy, A*, AllPointSearch

- **allpoint_type**: DP, BruteForce, Greedy

_For example_

**1. test blind search algorithms**

```
python main.py --search_name BFS --input_file sample_input.txt

python main.py --search_name DFS --input_file sample_input.txt

python main.py --search_name Greedy --input_file sample_input.txt
```

**2. A***

```
python main.py --search_name A* --input_file sample_input.txt
```

**3. level 3: get all points before reaching the goal**

```
python main.py --search_name AllPointSearch --input_file multi_points.txt --allpoint_type DP

python main.py --search_name AllPointSearch --input_file multi_points.txt --allpoint_type BruteForce

python main.py --search_name AllPointSearch --input_file multi_points.txt --allpoint_type Greedy
```

**4. level 4: polygon can move**
```
python heuristic_search_main.py
```

**5. level 5: Search in 3D map**
```
python 3d_main.py
```